# Remote HPS-controlled Debuggable and Reprogrammable FPGA project

## Objective

Based on HPS, FPGA portion can be reconfigured and PC interface can receive DE1-SoC board ouput signal with GUI. User can take use of either SignalTap with real-time debugging core or diectly receive end-point output signal such as VGA output, LED output and so on.
